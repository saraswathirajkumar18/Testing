package commonFunctions;

import java.util.Properties;
//import java.util.concurrent.TimeUnit;
import java.io.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class Common_Function {
	
	public static Properties properties;
	public static WebDriver driver;
	public Properties getPropertyFile() throws IOException
	{
	FileInputStream fileloc=new FileInputStream("config.properties");
	properties=new Properties();
	properties.load(fileloc);
	return properties;
	}
	
	@BeforeSuite
	public void launchBrowser() throws IOException
	
	{
	getPropertyFile();
	String browsername=properties.getProperty("browser");
	//browser.toLowerCase();
	switch(browsername.toLowerCase())
	{
	case "chrome":
		          driver=new ChromeDriver();
		          break;
	case "firefox":
		          driver= new FirefoxDriver();
		          break;
	case "microsoft edge":
		          driver=new EdgeDriver();
		          break;
    default:
    	    System.out.println("Please select one browser from given options:Chrome,Firefox,Microsoft Edge");
    	    break;
	        
	}
	String appUrl=properties.getProperty("url");
	driver.manage().window().maximize();
	driver.navigate().to(appUrl);
	//driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		
	}
   @AfterSuite
	public void tearDown()
	{
	driver.close();	
	}

}
