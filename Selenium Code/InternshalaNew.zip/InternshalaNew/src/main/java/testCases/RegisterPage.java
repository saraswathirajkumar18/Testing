package testCases;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import commonFunctions.Common_Function;
import pageObjects.RegisterPageObjects;

public class RegisterPage extends Common_Function {

@Test
public void userRegistration() throws InterruptedException
{
PageFactory.initElements(driver,RegisterPageObjects.class);
RegisterPageObjects.clickRegisterButton();
String semail=properties.getProperty("email");
String spassword=properties.getProperty("password");
String sfname=properties.getProperty("firstname");
String slname=properties.getProperty("lastname");
RegisterPageObjects.setUserEmail(semail);
RegisterPageObjects.setUserPassword(spassword);
RegisterPageObjects.setFirstName(sfname);
RegisterPageObjects.setLastName(slname);
RegisterPageObjects.termsCondition(driver);

RegisterPageObjects.clickSignupButton();

}
	

}
