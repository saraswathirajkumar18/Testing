package testCases;


import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import commonFunctions.Common_Function;
import pageObjects.LogoutPageObjects;


public class LogoutPage extends Common_Function {

	@Test
	public void checkLogoutFunc()
	{
		PageFactory.initElements(driver,LogoutPageObjects.class);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		LogoutPageObjects.clickUserProfile();	
		LogoutPageObjects.clickMoreOption();
		LogoutPageObjects.clickLogoutButton();
	
	}

}
