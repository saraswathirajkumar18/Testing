package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

//import testCases.Set;
import java.util.*;  

public class RegisterPageObjects {

@FindBy(xpath="//a[@class='register-student-cta' and text()='Candidate Sign-up']")
public static WebElement registerButton;

@FindBy(id="email")
public static WebElement email;

@FindBy(id="password")
public static WebElement password;

@FindBy(id="first_name")
public static WebElement firstName;

@FindBy(id="last_name")
public static WebElement lastName;

@FindBy(id="registration_submit")
public static WebElement signupButton;

@FindBy(linkText="Terms and Conditions")
public static WebElement termsCond;

public static void clickRegisterButton()
{
registerButton.click();	
}
public static void setUserEmail(String mail)
{
	email.sendKeys(mail);	
}
public static void setUserPassword(String pass)
{
	password.sendKeys(pass);
	
}
public static void setFirstName(String firstname)
{
	firstName.sendKeys(firstname);
}
public static void setLastName(String lastname)
{
	lastName.sendKeys(lastname);
	
}
public static void termsCondition(WebDriver driver) throws InterruptedException
{	
	String regpage=driver.getWindowHandle();
	termsCond.click();
	
	//System.out.println(driver.getTitle());
	
    Set<String> termscond=driver.getWindowHandles();
	for(String allopened:termscond) {
		if(!allopened.equals(regpage)) {
			
			driver.switchTo().window(allopened);
			Thread.sleep(5000);
			driver.close();
		}
	
	}
	  driver.switchTo().window(regpage);
  
	
	
}
public static void clickSignupButton()
{
	signupButton.click();
}





}
