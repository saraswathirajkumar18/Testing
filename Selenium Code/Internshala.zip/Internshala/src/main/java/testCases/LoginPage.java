
package testCases;
import java.io.*;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import commonFunctions.Common_Function;
import pageObjects.LoginPageObjects;

public class LoginPage extends Common_Function 

{
	@Test
	public void stulogin() throws InterruptedException
	{
		
	/*public String[] readData()
	{
	FileInputStream fileloc=new FileInputStream("logindata.xls");
	WorkBook book=new WorkBook(fileloc);
	Sheet excelsheet=new Sheet(book);
	int noofrows=excelsheet.;
	int noofcols=;
	
	}*/
	PageFactory.initElements(driver,LoginPageObjects.class);
	Thread.sleep(3000);
	String stuemail=properties.getProperty("email");
	String stupassword=properties.getProperty("password");
	LoginPageObjects.login();
	LoginPageObjects.setEmail(stuemail);
	LoginPageObjects.setPassword(stupassword);
	LoginPageObjects.studentLogin();
	}

	
}
                                                                                                                                                                                                          