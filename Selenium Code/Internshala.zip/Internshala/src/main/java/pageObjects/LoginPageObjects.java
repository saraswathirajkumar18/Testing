package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPageObjects {
	
@FindBy(xpath="//button[text()='Login' and @class='login-cta']")
public static WebElement loginbutton;

@FindBy(name="email")
public static WebElement studentEmail;

@FindBy(name="password")
public static WebElement studentPassword;

@FindBy(id="modal_login_submit")
public static WebElement loginSubmit;

@FindBy(id="forgot-password")
public static WebElement forgotPassword;

@FindBy(className="google_login")
public static WebElement loginByGoogle;

public static void login()
{
	loginbutton.click();
}
public static void setEmail(String stuemail)
{
	studentEmail.sendKeys(stuemail);
}
public static void setPassword(String stupassword)
{
	studentPassword.sendKeys(stupassword);
}
public static void studentLogin()

{
	loginSubmit.click();
	
}

}
