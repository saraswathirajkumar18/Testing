package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LogoutPageObjects {
	
@FindBy(xpath="(//div[contains(text(),'S') and @class=\"profile_icon_right\"])/ancestor::li")
public static WebElement dropdownHoverProfilecontainer;

@FindBy(xpath="(//a[contains(text(),'More')])/parent::li")
public static WebElement dropdownClickMoreOption;


@FindBy(xpath="(//li[@class=\"manage_account\"])/following-sibling::li")
public static WebElement logoutButton;

public  static void clickUserProfile()
{
	dropdownHoverProfilecontainer.click();	
}
public static void clickMoreOption()
{
	dropdownClickMoreOption.click();
}

public static void clickLogoutButton()
{
	logoutButton.click();
}

}
